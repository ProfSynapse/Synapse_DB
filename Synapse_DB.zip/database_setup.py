# Python Script for Building or Accessing the SQLite Database with Error Handling
import sqlite3

def create_or_connect_db(db_path):
    try:
        # Connect to the SQLite database or create it if it doesn't exist
        conn = sqlite3.connect(db_path)
        
        # Create a cursor object to execute SQL queries
        cursor = conn.cursor()
        
        # Create the table if it doesn't exist
        cursor.execute("""
CREATE TABLE IF NOT EXISTS conversation_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    context TEXT,
    summary TEXT,
    intent TEXT,
    sentiment TEXT,
    next_step TEXT,
    keywords TEXT
);
""")
        
        # Commit the changes
        conn.commit()
        
        print('Database setup was successful.')
    except sqlite3.Error as e:
        print(f'An error occurred: {e}')
    finally:
        # Close the connection
        if conn:
            conn.close()

# Specify the database path
db_path = 'conversation_data.db'

# Call the function to create or connect to the database
create_or_connect_db(db_path)
