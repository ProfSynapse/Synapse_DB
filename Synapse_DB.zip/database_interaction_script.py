# Database Interaction Script

import sqlite3

def insert_vector_into_db(vector, db_path='conversation_data.db'):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO vectors (vector) VALUES (?)", (vector,))
    conn.commit()
    conn.close()

def retrieve_vector_from_db(id, db_path='conversation_data.db'):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT vector FROM vectors WHERE id=?", (id,))
    vector = cursor.fetchone()
    conn.close()
    return vector

