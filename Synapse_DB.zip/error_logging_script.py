# Error Logging Script

def log_error(error_message):
    with open('error_log.txt', 'a') as log_file:
        log_file.write(error_message + '\n')

