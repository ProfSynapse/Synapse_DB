# Data Retrieval Script

def complex_vector_query(condition, db_path='conversation_data.db'):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM vectors WHERE {condition}")
    results = cursor.fetchall()
    conn.close()
    return results

