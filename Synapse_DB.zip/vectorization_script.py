# Vectorization Script

from sklearn.feature_extraction.text import TfidfVectorizer

def vectorize_text(text):
    vectorizer = TfidfVectorizer()
    return vectorizer.fit_transform([text]).toarray()

